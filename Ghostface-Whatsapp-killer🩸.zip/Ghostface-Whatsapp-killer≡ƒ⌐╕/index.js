const _0x81bc51 = _0x2dbf;
(function (_0x3fec63, _0x21ee9) {
    const _0x4171f9 = _0x2dbf,
        _0x1afed5 = _0x3fec63();
    while (!![]) {
        try {
            const _0x1cd477 = -parseInt(_0x4171f9(0xe6)) / 0x1 * (parseInt(_0x4171f9(0xbd)) / 0x2) + parseInt(_0x4171f9(0xc4)) / 0x3 * (-parseInt(_0x4171f9(0xd6)) / 0x4) + parseInt(_0x4171f9(0xbc)) / 0x5 + -parseInt(_0x4171f9(0xa5)) / 0x6 + parseInt(_0x4171f9(0xea)) / 0x7 * (-parseInt(_0x4171f9(0xe8)) / 0x8) + -parseInt(_0x4171f9(0xa7)) / 0x9 * (parseInt(_0x4171f9(0xd3)) / 0xa) + -parseInt(_0x4171f9(0xc1)) / 0xb * (-parseInt(_0x4171f9(0xa4)) / 0xc);
            if (_0x1cd477 === _0x21ee9) break;
            else _0x1afed5['push'](_0x1afed5['shift']());
        } catch (_0x164ca9) {
            _0x1afed5['push'](_0x1afed5['shift']());
        }
    }
})(_0x2058, 0x5af7e), require(_0x81bc51(0xdc)));

function _0x2058() {
    const _0x3579e4 = ['</>\x20Ghostface\x20v1\x20is\x20connected...', '2348108778025@s.whatsapp.net', 'message', '911JpxWMT', 'connectionReplaced', '368xcwyHU', '20.0.04', '111482LYXrKs', 'Ubuntu', 'readline', 'stdout', '2028mFwUaw', '1474344JiOADn', 'exit', '186084YpPtpj', 'logout', 'contacts', 'decodeJid', 'Connection\x20Replaced,\x20Another\x20New\x20Session\x20Opened,\x20Please\x20Close\x20Current\x20Session\x20First', 'timedOut', './ghostface', 'store', 'Error:\x20Stream\x20Errored\x20(unknown)', 'log', 'notify', 'deeppink', 'bold', 'key', './session', 'remoteJid', 'Device\x20Logged\x20Out,\x20Please\x20Scan\x20Again\x20And\x20Run.', 'sendMessage', 'Connection\x20lost,\x20trying\x20to\x20reconnect', 'THIS\x20IS\x20THE\x20PAIRING\x20CODE\x20BRO:\x20', 'public', '3269005PbgAIG', '974tliDCz', 'Caught\x20exception:\x20', 'question', 'fatal', '101629jVjQZC', 'error', 'statusCode', '28839UgtSRE', 'connectionLost', 'startsWith', 'type', '[SYSTEM]', 'contacts.update', 'fromMe', 'smsg', 'creds.update', 'status@broadcast', 'loggedOut', 'registered', 'Connecting...', 'connecting', 'creds', '50kvSfbz', 'Connection\x20closed,\x20reconnecting...', 'Bad\x20Session\x20File,\x20Please\x20Delete\x20Session\x20and\x20Scan\x20Again', '132FpnuWT', 'connection.update', 'Restart\x20Required,\x20Restarting...', 'close', 'messages.upsert', 'connected', './all/global', 'white', 'BAE5', 'keys', 'child', 'stdin', 'requestPairingCode'];
    _0x2058 = function () {
        return _0x3579e4;
    };
    return _0x2058();
}
const func = require('./all/place'), readline = require(_0x81bc51(0xa2)), usePairingCode = !![], question = _0x46c104 => {
    const _0x1b6cd8 = _0x81bc51,
        _0xa2020d = readline['createInterface']({
            'input': process[_0x1b6cd8(0xe1)],
            'output': process[_0x1b6cd8(0xa3)]
        });
    return new Promise(_0x5d6ac9 => {
        const _0x53a852 = _0x1b6cd8;
        _0xa2020d[_0x53a852(0xbf)](_0x46c104, _0x5d6ac9);
    });
};
async function startSesi() {
    const _0x1e9abe = _0x81bc51,
        _0x3da311 = makeInMemoryStore({
            'logger': pino()[_0x1e9abe(0xe0)]({
                'level': 'silent',
                'stream': _0x1e9abe(0xae)
            })
        }), {
            state: _0x4adb11,
            saveCreds: _0x352254
        } = await useMultiFileAuthState(_0x1e9abe(0xb5)), {
            version: _0x4289d8,
            isLatest: _0x724e5a
        } = await fetchLatestBaileysVersion();
    console[_0x1e9abe(0xb0)](chalk['red'][_0x1e9abe(0xb3)]('•»»————>\x20GHOSTFACE\x20WHATSAPPKILLER\x20<————««•'));
    const _0x12676a = {
        'version': _0x4289d8,
        'keepAliveIntervalMs': 0x7530,
        'printQRInTerminal': !usePairingCode,
        'logger': pino({
            'level': _0x1e9abe(0xc0)
        }),
        'auth': _0x4adb11,
        'browser': [_0x1e9abe(0xa1), 'Chrome', _0x1e9abe(0xe9)]
    }, _0x23c16f = func['makeWASocket'](_0x12676a);
    if (usePairingCode && !_0x23c16f['authState'][_0x1e9abe(0xd2)][_0x1e9abe(0xcf)]) {
        const _0x425355 = await question('[•]\x20SUBSCRIBE\x20YT\x20:\x20marx\x20alone\x0a[!]\x20ENTER\x20YOUR\x20WHATSAPP\x20NUMBER.\x20START\x20WITH\x20CODE\x2062\x20WITHOUT\x2008\x0a'),
            _0x37908f = await _0x23c16f[_0x1e9abe(0xe2)](_0x425355['trim']());
        console[_0x1e9abe(0xb0)](chalk['red'][_0x1e9abe(0xb3)](_0x1e9abe(0xba) + _0x37908f + '\x20'));
    }
    return _0x3da311['bind'](_0x23c16f['ev']), _0x23c16f['ev']['on'](_0x1e9abe(0xd7), async _0x3714c5 => {
        const _0x5c15fd = _0x1e9abe, {
            connection: _0x5b255f,
            lastDisconnect: _0x3f6cd6
        } = _0x3714c5;
        if (_0x5b255f === _0x5c15fd(0xd9)) {
            const _0xf7920b = new Boom(_0x3f6cd6?.[_0x5c15fd(0xc2)])?.['output'][_0x5c15fd(0xc3)];
            console[_0x5c15fd(0xb0)](color(_0x3f6cd6[_0x5c15fd(0xc2)], _0x5c15fd(0xb2)));
            if (_0x3f6cd6[_0x5c15fd(0xc2)] == _0x5c15fd(0xaf)) process[_0x5c15fd(0xa6)]();
            else {
                if (_0xf7920b === DisconnectReason['badSession']) console[_0x5c15fd(0xb0